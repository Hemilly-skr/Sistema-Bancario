class ContaPoupanca extends SistemaBancario {
    public ContaPoupanca(String nome, int numero, double saldo) {
        this.nome = nome;
        this.numero = numero;
        this.saldo = saldo;
    }
}