import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        ContaCorrente contaCorrente = null;
        ContaPoupanca contaPoupanca = null;

        while (true) {
            System.out.println("Bem-vindo ao aplicativo de lista de Sistema Bancário!");
            System.out.println("Escolha uma opção:");
            System.out.println("1. Criar conta corrente");
            System.out.println("2. Criar conta poupança");
            System.out.println("3. Depositar na conta Corrente");
            System.out.println("4. Depositar na conta Poupança");
            System.out.println("5. Visualizar dados da conta");
            System.out.println("6. Sacar");
            System.out.println("7. Sair");

            int opcao = scanner.nextInt();
            scanner.nextLine(); 

            switch (opcao) {
                case 1:
                    System.out.println("Olá, hoje iremos criar sua conta corrente!");
                    System.out.println("Digite o seu nome: ");
                    String nomeCorrente = scanner.nextLine();
                    System.out.println("Digite o número da conta: ");
                    int numeroCorrente = scanner.nextInt();
                    System.out.println("Digite o saldo da conta: ");
                    double saldoCorrente = scanner.nextDouble();
                    contaCorrente = new ContaCorrente(nomeCorrente, numeroCorrente, saldoCorrente);
                    break;
                case 2:
                    System.out.println("Olá, hoje iremos criar sua conta poupança!");
                    System.out.println("Digite o seu nome: ");
                    String nomePoupanca = scanner.nextLine();
                    System.out.println("Digite o número da conta: ");
                    int numeroPoupanca = scanner.nextInt();
                    System.out.println("Digite o saldo da conta: ");
                    double saldoPoupanca = scanner.nextDouble();
                    contaPoupanca = new ContaPoupanca(nomePoupanca, numeroPoupanca, saldoPoupanca);
                    break;
                case 3:
                    if (contaCorrente != null) {
                        System.out.println("Digite o valor a ser depositado na conta corrente: ");
                        double valorCorrente = scanner.nextDouble();
                        contaCorrente.depositar(valorCorrente);
                    } else {
                        System.out.println("Você não tem uma conta corrente criada.");
                    }
                    break;
                case 4:
                    if (contaPoupanca != null) {
                        System.out.println("Digite o valor a ser depositado na conta poupança: ");
                        double valorPoupanca = scanner.nextDouble();
                        contaPoupanca.depositar(valorPoupanca);
                    } else {
                        System.out.println("Você não tem uma conta poupança criada.");
                    }
                    break;
                case 5:
                    if (contaCorrente != null) {
                        contaCorrente.visualizarDados();
                    } else {
                        System.out.println("Você não tem uma conta corrente criada.");
                    }
                    if (contaPoupanca != null) {
                        contaPoupanca.visualizarDados();
                    } else {
                        System.out.println("Você não tem uma conta poupança criada.");
                    }
                    break;
                case 6:
                    System.out.println("Funcionalidade de saque ainda não implementada.");
                    break;
                case 7:
                    System.out.println("Saindo do sistema.");
                    scanner.close();
                    return;
                default:
                    System.out.println("Opção inválida. Tente novamente.");
            }
        }
    }
}