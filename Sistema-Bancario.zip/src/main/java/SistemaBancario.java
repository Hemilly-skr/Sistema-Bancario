class SistemaBancario {
    protected String nome;
    protected int numero;
    protected double saldo;

    public void depositar(double valor) {
        this.saldo += valor;
        System.out.println("Depósito de " + valor + " realizado com sucesso.");
    }

    public void visualizarDados() {
        System.out.println("Nome: " + nome);
        System.out.println("Número da conta: " + numero);
        System.out.println("Saldo: " + saldo);
    }
}
