class ContaCorrente extends SistemaBancario {
    public ContaCorrente(String nome, int numero, double saldo) {
        this.nome = nome;
        this.numero = numero;
        this.saldo = saldo;
    }
}
